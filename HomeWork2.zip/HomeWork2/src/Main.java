import java.util.Arrays;
import java.util.Scanner;

/**
 * Домашнее задание 2
 */
public class Main {
    /**
     *    /**
     * Пункт 1: Создать массив состоящий из элементов 0 и 1.
     * Вариант 1:
     */
    public static int[] resultOperation(){
        int[] arr = new int[10];
        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) { arr[i] = 1;}

        }
        return arr;
    }

    /**
     * Пункт 2: В массиве из предыдущего пункта, с помощью цикла заменить 0 на 1, 1 на 0;
     * @param arr
     */
    public static int[] resultOperation2(int[] arr){
        int[] arr2 = new int[10];
        arr2= arr.clone();
        for (int i = 0; i < 10; i++) {
            if (arr2[i] == 1) {
                arr2[i] = 0;
            } else {arr2[i] = 1;}
        }
        return arr2;
    }

    /**
     * Пункт 3: Создать массив из 8 целых чисел.
     * С помощью цикла заполнить его значениями 1 4 7 10 13 16 19 22;
     */
    public static int[] resultOperation3(){
        int[] arr3 = new int[8];
        int k = 1;
        for (int i = 0; i < 8; i++) {
            arr3[i]=k;
            k+=3;
        }
        return arr3;
    }

    /**
     * Пункт 4: Задать массив int[] mas = { 1, 5, 3, 2, 11, 4, 5, 2, 4, 8, 9, 1 };
     * пройти по нему циклом, и числа которые меньше 6 умножить на 2.
     */
    public static int[] resultOperation4(){
        int[] mas = { 1, 5, 3, 2, 11, 4, 5, 2, 4, 8, 9, 1 };
        for (int i = 0; i <mas.length ; i++) {
            if (mas[i] < 6) {
               mas[i]*=2;
            }
        }
        return mas;
    }

    /**
     * Пункт 5: Задать одномерный массив и найти в нем минимальный и максимальный элементы;
     * @param args
     */
    public static void resultOperation5(){
        int[] mas = {2, 15, 3, 26, 1, 7};
        int kSmall = 0;
        int kBig = 0;
        int[] mas2 = mas.clone();
        //System.out.println(Arrays.toString(mas2));
        for (int i = 0; i <mas.length ; i++) {
            int k = mas[i];
            for (int j = 0; j <mas.length ; j++) {
                if (mas[i]>mas2[j]) {
                    kSmall = mas2[j];
                    //System.out.println(kSmall);
                    //break;
                }
                if (mas[i]<mas2[j]) {
                    kBig = mas2[j];
                }
            }
        }
        System.out.println("Small number: " + kSmall);
        System.out.println("Big number: " + kBig);
    }

    /**
     * Пнукт 6: Написать простой консольный калькулятор.
     * Пользователь вводит два числа и операцию которую хочет выполнить, программа вычисляет результат и выводит в консоль;
     * @param args
     */
    public static void resultOperation6(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Vvedite chislo:");
        int a;
        a = sc.nextInt();
        System.out.println("Vvedite chislo:");
        int b;
        b = sc.nextInt();
        int result1 = a+b;
        int result2 = a-b;
        int result3 = a*b;
        int result4 = a/b;
        System.out.println("Vvedite operation: +,-,*,/");
        String c;
        c = sc.next();
        switch (c){
            case "+":
                System.out.println("Operation a+b: " + result1);
                break;
            case "-":
                System.out.println("Operation a-b: " + result2);
                break;
            case "*":
                System.out.println("Operation a*b: " + result3);
                break;
            case "/":
                System.out.println("Operation a/b: " + result4);
                break;
        }
    }

    public static void main(String[] args) {
        /**
         * Пункт 1:
         */
        System.out.println("resultOperation - punkt 1:");
        System.out.println(Arrays.toString(resultOperation()));
        /**
         * Пункт 2:
         */
        System.out.println("resultOperation2 - punkt2:");
        //int[] arr2 = new int[10];
        //arr2 = resultOperation().clone();
        //System.out.println(Arrays.toString(resultOperation2(arr2)));
        System.out.println(Arrays.toString(resultOperation2(resultOperation())));
        /**
         * Пункт 3:
         */
        System.out.println("resultOperation3 - punkt3:");
        System.out.println(Arrays.toString(resultOperation3()));
        /**
         * Пункт 4:
         */
        System.out.println("resultOperation4 - punkt4:");
        System.out.println(Arrays.toString(resultOperation4()));
        /**
         * Пункт 5:
         */
        System.out.println("resultOperation5 - punkt5:");
        resultOperation5();
        /**
         * Пункт 6:
         */
        System.out.println("resultOperation6 - punkt6:");
        resultOperation6();
    }
}
