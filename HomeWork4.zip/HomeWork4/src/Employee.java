/**
 * Пункт 1:  Создать класс "Сотрудник" с полями: ФИО, должность, email, телефон, зарплата, возраст
 */
public class Employee {
    /**
     * Поля класса
     */
    private String fIO;
    private String postWork;
    private String eMail;
    private String telefoneNumber;
    //Зарплата
    private int salary;
    //Возраст
    private int age;

    /**
     * Конструктор класса
     * Пункт 2: Конструктор класса должен заполнять эти поля при создании объекта
     */
    public Employee(String fIO, String postWork, String eMail, String telefoneNumber, int salary, int age) {
        this.fIO = fIO;
        this.postWork = postWork;
        this.eMail = eMail;
        this.telefoneNumber = telefoneNumber;
        this.salary = salary;
        this.age = age;
    }

    /**
     * Пункт 3: Внутри класса «Сотрудник» написать метод, который выводит информацию об объекте в консоль
     */
    public void aboutEmployee(){
        System.out.println("ФИО работника: " + fIO + "\n"
                + "Должность работника: " + postWork + "\n"
                + "Почта работника: " + eMail  + "\n"
                +  "Телефон работника: " + telefoneNumber  + "\n"
                + "Возраст работника: " + age);
    }
    /**
     * Для доступа к значениям полей класса,
     * если поля обяъвлены с модификатором доступа private,
     * используются мутоды get и set
     */
    public String getfIO() {
        return fIO;
    }

    public void setfIO(String fIO) {
        this.fIO = fIO;
    }

    public String getPostWork() {
        return postWork;
    }

    public void setPostWork(String postWork) {
        this.postWork = postWork;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getTelefoneNumber() {
        return telefoneNumber;
    }

    public void setTelefoneNumber(String telefoneNumber) {
        this.telefoneNumber = telefoneNumber;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
