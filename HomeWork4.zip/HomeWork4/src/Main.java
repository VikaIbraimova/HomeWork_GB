import java.util.Random;

/**
 * Created by vika on 01.05.2016.
 */
public class Main {

    public static void main(String[] args) {


        /**
         * Конструктор класса
         * Пункт 2: Конструктор класса должен заполнять эти поля при создании объекта
         */
        Employee emp1 = new Employee("Иванов П.П.","программсит","myMail@mail.ru","9-47-56",54,27);
        /**
         * Пункт 4:Создать массив из 5 сотрудников
         */
        /**
         * Чтобы объекты были разные создадим
         */
        //String[] fio = {"Евгений","Мария","Константин","Дмитрий","Илья"};
        String[] postWork = {"программист", "секретарь", "администратор", "директор"};
        //String eMail = "pochta";
        //Телефон формируется случайным образом
        Random rand = new Random();
        //Возраст работника формируется тоже случайным образом


        Employee[] employees = new Employee[5];
        /*Employee[i] = new Employee(
                "ФИО: " + fio[i] + "Должность: " + postWork[i]
                        + "E-mail: " + eMail+i+"mail.com"
                        + "Телефон: " + rand.nextInt(10) + "Зарплата: " + rand.nextInt(10)+ "Возвраст: " + rand.nextDouble());
        */
        /**
         * Переменная для номера телефона
         */
        String numTelefone;
        for (int i = 0; i < 5; i++)
            employees[i] = new Employee(
                    "fio_Employee-" + i,
                    "postWork_Employee-" + i,
                    "email_Employee-" + i,
                    //"telefonNumber" + i,
                    //"0 + (int)(Math.random() * ((14 - 5) + 1))0 + (int)(Math.random() * ((14 - 5) + 1))0 + (int)(Math.random() * ((14 - 5) + 1))0 + (int)(Math.random() * ((14 - 5) + 1))0 + (int)(Math.random() * ((14 - 5) + 1))",
                    //"123456",
                    //numTelefone = Integer.toString(i),
                    //numTelefone = Integer.toString(0 + (int) (Math.random() * ((14 - 5) + 1))),
                    numTelefone = (Integer.toString(0 + (int) (Math.random() * ((14 - 5) + 1)))
                            +Integer.toString(0 + (int) (Math.random() * ((14 - 5) + 1)))
                            +Integer.toString(0 + (int) (Math.random() * ((14 - 5) + 1)))
                            +Integer.toString(0 + (int) (Math.random() * ((14 - 5) + 1)))
                            +Integer.toString(0 + (int) (Math.random() * ((14 - 5) + 1)))
            ),
                    20 + (int) (Math.random() * ((40 - 5) + 1)),
                    20 + (int) (Math.random() * ((50 - 5) + 1))
            );

        /**
         * Пункт 5: С помощью цикла вывести информацию только о сотрудниках старше 40 лет
         */
        for (int i = 0; i < 5; i++) {
            if(employees[i].getAge()>40) employees[i].aboutEmployee();
        }
    }
}
