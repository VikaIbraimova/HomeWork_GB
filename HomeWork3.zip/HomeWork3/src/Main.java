import java.util.Random;
import java.util.Scanner;

/**
 * Пример игры крестики-нолики в процедурном стиле
 */
public class Main {

    /**
     * Объявим поле для игры
     * @param args
     */
    static char[][] map;
    //Чтобы можно было вводить ходы
    static Scanner sc = new Scanner(System.in);
    /**
     * Символы для игры
     */
    static final char humanDot = 'X';
    static final char aiDot = 'O';
    static final String result = "GAME OVER";
    static final String result2 = "Human Win";
    static final String result3 = "Computer Win";

    //Для компьютера ходы будет формировать генератор случайных чисел
    static Random rand = new Random();

    /**
     * Заполним массив символом * - это означает, что это поле пустое
     * @param args
     */
    public static void initMap(){
        /**
         * Выделяем память
         */
        map = new char[3][3];
        //i строка
        for (int i = 0; i < 3; i++) {
            //j столбец
            for (int j = 0; j < 3; j++) {
                map[i][j] = '*';
            }
        }
    }

    /**
     * Показываем наше поле
     * @param args
     */
    public static void showMap(){
        System.out.println("0 1 2 3");
        for (int i = 0; i < 3; i++) {
            System.out.print(i+1 + " ");
            //j столбец
            for (int j = 0; j < 3; j++) {
                System.out.print(map[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    /**
     * Ходы человека
     * @param args
     */
    public static void humanTurn(){
        int x,y;

        do {
            System.out.println("Введите ячейку в формате X Y");
            /**
             * Так как инициализация массива идет с нуля,
             * то что бы попатсь в ячейку 1 1, нужно вычесть 1
             */
            x = sc.nextInt()-1;
            y = sc.nextInt()-1;
        } while(!isCellEmpty(x,y));
        map[y][x] = humanDot;
    }

    /**
     * Ходы человека
     * @param args
     */
    public static void aiTurn(){
        int x,y;

        do {
            /**
             * У компьютера выбор ячейки осуществляется
             * с помощью класса Random
             */
            x = rand.nextInt(3);
            y = rand.nextInt(3);
        } while(!isCellEmpty(x,y));
        map[y][x] = aiDot;
    }
    /**
     * Проверяем пустая ли ячейка перед ходом
     * @param args
     */
    public static boolean isCellEmpty(int x,int y){
        /**
         * Проверяем корректные ли индекс ячейки ввель пользователь
         */
        if (x<0||y<0||x>2||y>2) return false;
        if (map[y][x] == '*') return true;
        return false;
    }

    /**
     * Метод говорит, что карта заполнена полностью
     * @param args
     */
    public static boolean isMapFull(){
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (map[i][j] == '*') return false; //поле еще не заполнено, тоесть есть свободные ячейки
            }
        }
        /**
         * Все поля заполнены и
         * ходить больше некуда
         */
        return true;
    }

    //Выявляем победителя
    public static boolean checkWin(char dot){
        /**
         * char dot - проверяем заполнение крестиками
         * или отдельно ноликами
         */
        //Проверяем построчно
        if(map[0][0] == dot && map[0][1] == dot && map[0][2] == dot) return true;
        if(map[1][0] == dot && map[1][1] == dot && map[1][2] == dot) return true;
        if(map[2][0] == dot && map[2][1] == dot && map[2][2] == dot) return true;

        //Проверяем по столбцам
        if(map[0][0] == dot && map[1][0] == dot && map[2][0] == dot) return true;
        if(map[0][1] == dot && map[1][1] == dot && map[2][1] == dot) return true;
        if(map[0][2] == dot && map[1][2] == dot && map[2][2] == dot) return true;

        //Проверяем диагонали
        if(map[0][0] == dot && map[1][1] == dot && map[2][2] == dot) return true;
        if(map[2][0] == dot && map[1][1] == dot && map[0][2] == dot) return true;

        return false;
    }
    //Дополнительные методы

    /**
     * Метод описывает любую возможную линию для
     * исследования на поле
     * @param cx
     * @param cy
     * @param vx
     * @param vy
     * @param l
     * @param dot
     * @return
     */
    public static boolean checkLine(int cx, int cy,int vx, int vy, int l, char dot){
        /**
         * cx,cy - координаты начала линии
         * vx,vy - координаты напарвления линии
         * l -длина(колличество крестиков или ноликов)
         * dot - из каких символов состоит
         */
        for (int i = 0; i < l; i++) {
            if (map[cy+i*vy][cx+i*vx]!=dot) return false;
        }
        return true;
    }

    public static boolean checkWinX(char dot){
        for (int i = 0; i < 3; i++) {
            if (checkLine(1,0,0,1,3,dot)) return true;
            if (checkLine(0,1,1,0,3,dot)) return true;
        }
        if (checkLine(0,0,1,1,3,dot)) return true;
        if (checkLine(0,2,1,-1,3,dot)) return true;
        return false;

    }
    public static void main(String[] args) {
        //Инициализировали карту
        initMap();
        //Отпечатали
        showMap();
        while(true){
            //Дали человеку походить
            humanTurn();
            //Отпечатали(показали обновленную карту)
            showMap();
            //Победил человек?
            if(checkWin(humanDot)) {
                System.out.println(result2);
                break;
            }
            //Проверяем,если ли еще свободные ячейки
            if(isMapFull()) {
                System.out.println(result);
                break;
            }
            aiTurn();
            showMap();
            //Победил компьютер?
            //Победил человек?
            if(checkWin(aiDot)) {
                System.out.println(result3);
                break;
            }
            if(isMapFull()) break;
        }
        System.out.println(result);
    }
}
