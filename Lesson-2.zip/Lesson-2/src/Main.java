/**
 * Домашнее задание
 */
public class Main {
    public static void main(String[] args) {
        //System.out.println(0 % 2);
        //System.out.println(1 % 2);
        //int[] arr = {1, 1, 0, 0, 1, 0, 1, 1, 0, 0};
        //System.out.println(Arrays.toString(arr));
        /*int[] a = new int[10];
        for (int i = 0; i <10 ; i+=2) {
           a[i] = i;
        }
        System.out.println(a.toString());*/
/*        int[] b = new int[10];
        for (int i = 0; i <10 ; i++) {
            b[i] = i+2;
         }
        System.out.println(Arrays.toString(b));*/
    /*int[][] a = new int[3][3];
        int k = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                a[i][j] = k;
                k++;
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
        }*/
       /* for (int i = 0; i <10 ; i++) {
            if (i==3) break;
            System.out.println("i: "+i);
        }*/
        int a = 4;
        switch (a) {
            case 3:
                System.out.println("a=3");
                break;
            case 4:
                System.out.println("a=4");
                break;
            case 5:
                System.out.println("a=5");
                break;
            default:
                System.out.println("def");
        }
        System.out.println("end");
/*        System.out.println(2 % 2);
        System.out.println(3 % 2);
        System.out.println(4 % 2);
        System.out.println(5 % 2);
        System.out.println(6 % 2);
        System.out.println(7 % 2);
        System.out.println(8 % 2);
        System.out.println(9 % 2);
        System.out.println(10 % 2);
        System.out.println(101 % 2);*/

        /**
         * Пункт 1: Создать массив состоящий из элементов 0 и 1,
         * например int[] arr = { 1, 1, 0, 0, 1, 0, 1, 1, 0, 0 };
         */
        /*public static void resultOperation(){
            int[] arr = { 1, 1, 0, 0, 1, 0, 1, 1, 0, 0 };
            //int[] arr2;
            //System.out.println(0 % 2);
            System.out.println(Arrays.toString(arr));
        }*/
    }
}